package com.soushetty.todo.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "todo_table")
public class ToDo {
    /*this is an entity which represents table.In this database everything is an object.
    using annotations to depict how the table should be */
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String todo;

    public ToDo(String todo) {
        this.todo = todo;
    }

    public String getTodo() {
        return todo;
    }
}
